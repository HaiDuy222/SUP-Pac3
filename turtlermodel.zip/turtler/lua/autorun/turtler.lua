if SERVER then
	AddCSLuaFile()
end

player_manager.AddValidModel("trooper by Bluur", "models/cac/turtler/purgetrooper.mdl")