//custom
player_manager.AddValidHands( "custom spacemarine", "models/player/Jenssons/arms/customhand.mdl", 0, "00000000" )

player_manager.AddValidModel( "custom spacemarine", 							"models/player/Jenssons/custom.mdl" )

list.Set( "PlayerOptionsModel",  "custom spacemarine", 							"models/player/Jenssons/custom.mdl" )


//bloodraven
player_manager.AddValidHands( "bloodraven", "models/player/Jenssons/arms/spacemarinehand.mdl", 0, "00000000" )

player_manager.AddValidModel( "bloodraven", 							"models/player/Jenssons/spacemarine.mdl" )

list.Set( "PlayerOptionsModel",  "bloodraven", 							"models/player/Jenssons/spacemarine.mdl" )

local Category = "Jenssons"


local NPC = { Name = "BloodRaven",
Class = "npc_citizen",
Model = "models/player/Jenssons/NPC/spacemarine.mdl",
Health = "200",
KeyValues = { citizentype = 4 },
Category = Category }

list.Set( "NPC", "npc_bloodraven", NPC )


//ultramarines
player_manager.AddValidHands( "ultramarines", "models/player/Jenssons/arms/ultramarineshand.mdl", 0, "00000000" )

player_manager.AddValidModel( "ultramarines", 							"models/player/Jenssons/ultramarines.mdl" )

list.Set( "PlayerOptionsModel",  "ultramarines", 							"models/player/Jenssons/ultramarines.mdl" )

local Category = "Jenssons"


local NPC = { Name = "Ultramarines",
Class = "npc_citizen",
Model = "models/player/Jenssons/NPC/ultramarines.mdl",
Health = "200",
KeyValues = { citizentype = 4 },
Category = Category }

list.Set( "NPC", "npc_ultramarines", NPC )

//darkangels
player_manager.AddValidHands( "darkangels", "models/player/Jenssons/arms/darkangelshand.mdl", 0, "00000000" )

player_manager.AddValidModel( "darkangels", 							"models/player/Jenssons/darkangels.mdl" )

list.Set( "PlayerOptionsModel",  "darkangels", 							"models/player/Jenssons/darkangels.mdl" )

local Category = "Jenssons"


local NPC = { Name = "Darkangels",
Class = "npc_citizen",
Model = "models/player/Jenssons/NPC/darkangels.mdl",
Health = "200",
KeyValues = { citizentype = 4 },
Category = Category }

list.Set( "NPC", "npc_darkangels", NPC )
