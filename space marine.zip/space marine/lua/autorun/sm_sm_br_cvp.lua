list.Set( "PlayerOptionsModel", "Blood Raven_cvp", "models/player/lordvipes/sm_sm_br/sm_sm_br_cvp.mdl" )

player_manager.AddValidHands( "Blood Raven_cvp", "models/player/lordvipes/sm_sm_br/Arms/sm_sm_br_arms_cvp.mdl", 0, "00000000" )

player_manager.AddValidModel( "Blood Raven_cvp", "models/player/lordvipes/sm_sm_br/sm_sm_br_cvp.mdl" )